module.exports = (server) => {
  console.log(server);
};
