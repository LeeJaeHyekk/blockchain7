let count = 0;
const music = new Audio();

let player1;
let player2;

life = () => {};

const test = document.getElementById("asd");
test.onclick = () => {
  document.getElementById("music1").play();
};
