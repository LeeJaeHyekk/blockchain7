const router = require("express").Router();

// express 서버에서 사용하는 라우터를 생성한다.
// router를 전부 관리하는 루트 이다.
// router에 대한 루트 파일 이라고 이야기 할수 있다.
// get , post , put , path , delete
// 위 5개의 방식으로 통신을 하는 방식을 Rest Api라고 한다.
// REST API = RESTFUL API = RESTFUL
// HTTP통신 , 즉 Web 통신을 할 때 기본적으로 사용되는 방식이다.
// REST API VS GraphGl << 요런 놈이 있긴 하다.

const { Table1 } = require("../models/index.js");

router.get("/", async (req, res, next) => {
  const { body, query } = req;
  const options = {};
  if (query.colum2) {
    options.where = {
      // 어떤 조건으로 찾을꺼냐?
      colum2: query.colum2,
      // column2 가  query.column2인 애를 찾겠다.
    };
  }
  const tempTables = await Table1.findAll(options);
  // const temptables =await Talble1.findALL{
  // where:{
  // column2:query.column2
  // }
  // }
  res.send({ name: "get", body, query, tempTables });
  // res.cookie("middle", "testing");
  next();
});
//  요 위가 미들 웨어 이다.
// router.get("/", (req, res) => {
//   const { body, query } = req;
//   res.send({ name: "get", body, query });
// });
router.post("/", async (req, res) => {
  const { body, query } = req;
  const tempTable = await Table1.create({
    colum1: body.colum1,
  });
  res.send({ name: "post", body, query });
});
router.put("/", async (req, res) => {
  // 하나씩 바꿀꺼면 put
  const { body, query } = req;
  const tempTable = await Table1.update(
    { colum1: body.colum1, birthDay: 11 },
    //  수정할 정보 입력
    {
      where: {
        colum2: body.colum2,
      },
      // 바꿀려는 값
    }
  );
  res.send({ name: "put", body, query });
});
router.patch("/", (req, res) => {
  // 하나씩 바꾼다. 일부분만 수정할때
  const { body, query } = req;
  res.send({ name: "patch", body, query });
});
router.delete("/", async (req, res) => {
  const { body, query } = req;
  const tempTable = await Table1.destroy({
    where: {
      colum1: query.colum1,
    },
  });
  res.send({ name: "delete", body, query, tempTable });
});
module.exports = router;
// express 서버의 root에 연결 하기 위해서 생성한 라우터를 외부로 보낸다?
