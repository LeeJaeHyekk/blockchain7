const router = require("express").Router();
// express 서버에서 사용하는 라우터를 생성한다.
const table1 = require("./table1.js");
const table2 = require("./table2.js");
router.use("/", (req, res, next) => {
  console.log(req.body, req.query);
  next(); // 다음으로 넘긴다 .. 없으면 무한 정지가 될수도 있다.
  //  res.end() 등등이 없으면 응답을 보내지 않으므로 next가 없으면 응답 하지 않는 상태로 멈춰 있다.
  //   next() 가 있으면 다음 흐름으로 넘어간다.
  //   res.end(); == res.send() == res.json  여기서 끝낸다
});
router.use("/table1", table1);
router.use("/table2", table2);
module.exports = router;
