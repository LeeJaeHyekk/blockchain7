"use strict";
// 염격모드 : ES6 안됨 , var 안되고 빡쌔게 코드를 작성한다.
// DB의 Table에 관련해서 전부 관리한다.
// MVC  << model , view , controller
// view : 보이는거  controller : 조작 , 통제  , model :저장 하는거
const Sequelize = require("sequelize");
// sequlize : DB에 연결합니다. == 무슨 DB든 다 가능하다.
// mysql2 : DB에 연결한다. => mysql에 접근
const Table1 = require("./table1.js");
const Table2 = require("./table2.js");
const env = process.env.NODE_ENV || "development";
const config = require(__dirname + "/../config/config.json")[env];
const db = { Table1, Table2 };

let sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  config
);

Table1.init(sequelize);
Table2.init(sequelize);

Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;

// class A {
//   constructor() {
//     this.a = 1;
//   }
//   test(num) {
//     console.log(num);
//   }
//   static testStatic(num) {}
// }
// console.log(new A());

// class B extends A {
//   constructor() {
//     super();
//     this.b = 2;
//   }
// }
// console.log(new B());
//  static 메서드  ,,, 일반적인 메서드
// model 에서 쓸때 사용해야 된다.
