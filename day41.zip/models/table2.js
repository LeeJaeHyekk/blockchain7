const Sequelize = require("sequelize");
const router = require("../routes");
module.exports = class Talble2 extends Sequelize.Model {
  static init(sequelize) {
    return super.init(
      {
        column3: {
          type: Sequelize.STRING(255),
        },
        column4: {
          type: Sequelize.BOOLEAN,
        },
      },
      {
        sequelize,
        timestamps: true,
        underscored: true,
        paranoid: false,

        modelName: "Talble2",
        tableName: "table2",
        charset: "utf8mb4",
        collate: "utf8mb4_general_ci",
      }
    );
  }
  static associate(db) {
    Talble2.belongsTo(db.Table1, {
      // table1이 table2를 갖고 있다.
      // (table2가 어딘가 (table1)에 속해있다.)
      foreignKey: "table_column2",
      // 연결하는키
      targetKey: "column2",
      // 상대한테 받아올 키(컬럼)
    });
  }
};
