const Sequelize = require("sequelize");
// C = create / insert , R = read // findall,findone / select , U = update / update , D = delete / delete
module.exports = class Table1 extends Sequelize.Model {
  // class *** : 클래스 선언
  // extends : 상속을 받는다, 오른쪽에 있는걸 기본으로 왼쪽 , 즉 지금 선언한걸 클래스로 생성한다.
  //   오른쪽에 있는 내용은 전부 왼쪽에도 있다.
  static init(sequelize) {
    // 테이블을 생성
    return super.init(
      {
        column1: {
          type: Sequelize.STRING(10),
          //   javascript 에 숫자가 들어올떄 정수인지 실수 인지 알수가 없어서 DB에서 알수 있게 하기 위해서 쓴다.
        },
        column2: {
          // type:sequelize.NUMBER
          type: Sequelize.INTEGER.UNSIGNED,
          //   type: Sequelize.Number  얘는 index 로 사용하지 못한다.
          // int 가 아니라 숫자이다. FLOT ?/ DOUBLE 둘 중 하나일 것이다.
          //   UNSIGNED 는 | 0<num | << 음수 없이 0과 양수로만 이루어져 있다. -20억 ~ 20억 / 0~40 억  용량은 그대로 이기 때문이다.
          primaryKey: true, // 데이블당 하나만 가능하다  검색에 용이하다
          unique: true, // 데이터가 중복될 수 없다.
          autoIncrement: true, // 자동증가
        },
      },
      {
        // 테이블에 대한 기본 설정
        sequelize,
        timestamps: true, //create_at, update_at 을 자동으로 추가헌다.
        underscored: true, // 카멜을 스네이크로 바꾼다.
        paranoid: false, // delete_at을 추가한다. 데아터를 삭제했을때 DB에서 아예 없앨건지, 아니면 남길건지 결정해라<< true면 남긴다. <<delete_at 이 추가된다.

        modelName: "Talble1", // javascript에서 사용되는 이름
        tableName: "table1", // DB에 생성되는 이름
        charset: "utf8mb4", //
        collate: "utf8mb4_general_ci",
      }
    );
  }
  static associate(db) {
    //관계를 위한 메서드
    Table1.hasMany(db.Table2, {
      // table2 를 많이 갖고 있다.
      foreignKey: "table1_column2",
      //   연결 하는 키
      sourceKey: "column2",
      //   상대가 저장할 키
      as: "Table2s",
      //   상대를 찾거나 추가 하거나 등등에 사용
    });
  }
};
